// import supertest from 'supertest';
// const request = supertest('https://gorest.co.in/public-api/')

// import { expect } from 'chai';

// const TOKEN =  
//                '60ea07fbb62720499d00749ad490c70ce57ebf147ef7df29aadde1635deda4f8';

// describe ('Users', () => {
//     it('GET/users', (done) => {
//      request.get(`users?access-token=${TOKEN}`).end((err,res) => {
//        expect(res.body.data).to.not.be.empty;
//         expect(res.body.code).to.equal(200);
//        // expect(res.body.data.gender).to.equal('male');
//        console.log(res.body.data[0].name);
//          done();
         
//      });
//     }); 
// });
