import supertest from 'supertest';
import { expect } from 'chai';

const yaml = require('js-yaml')
const fs = require('fs')

const file = fs.readFileSync('./meals.yml', 'utf8');
const conf = yaml.load(file);

console.log("The target server is: " + conf.mealserver);
const request = supertest(conf.mealserver)




describe ('NoGarlicIngredientTestSuite', () => {
    it('GET/randomMeal1', (done) => {
     request.get(`random.php`).end((err,res) => {
     expect(res.body.meals).to.not.be.empty;
     expect(res.status).to.equal(200);
     expect(res.body.meals[0].strIngredient1).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient2).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient3).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient4).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient5).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient6).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient7).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient8).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient9).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient10).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient11).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient12).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient13).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient14).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient15).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient16).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient17).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient18).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient19).to.not.equal('Garlic');
     expect(res.body.meals[0].strIngredient20).to.not.equal('Garlic');
    // console.log(res.body.meals[0]);
   //  console.log(res.status);
    // console.log(err);
         done();
         
     });
    }); 

    it('GET/randomMeal2', (done) => {
        request.get(`random.php`).end((err,res) => {
        expect(res.body.meals).to.not.be.empty;
        expect(res.status).to.equal(200);
        expect(res.body.meals[0].strIngredient1).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient2).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient3).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient4).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient5).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient6).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient7).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient8).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient9).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient10).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient11).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient12).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient13).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient14).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient15).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient16).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient17).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient18).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient19).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient20).to.not.equal('Garlic');
       // console.log(res.body.meals[0]);
      //  console.log(res.status);
       // console.log(err);
            done();
            
        });
       }); 

       it('GET/randomMeal3', (done) => {
        request.get(`random.php`).end((err,res) => {
        expect(res.body.meals).to.not.be.empty;
        expect(res.status).to.equal(200);
        expect(res.body.meals[0].strIngredient1).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient2).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient3).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient4).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient5).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient6).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient7).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient8).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient9).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient10).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient11).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient12).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient13).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient14).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient15).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient16).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient17).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient18).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient19).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient20).to.not.equal('Garlic');
       // console.log(res.body.meals[0]);
      //  console.log(res.status);
       // console.log(err);
            done();
            
        });
       }); 
       it('GET/randomMeal4', (done) => {
        request.get(`random.php`).end((err,res) => {
        expect(res.body.meals).to.not.be.empty;
        expect(res.status).to.equal(200);
        expect(res.body.meals[0].strIngredient1).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient2).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient3).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient4).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient5).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient6).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient7).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient8).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient9).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient10).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient11).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient12).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient13).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient14).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient15).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient16).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient17).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient18).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient19).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient20).to.not.equal('Garlic');
       // console.log(res.body.meals[0]);
      //  console.log(res.status);
       // console.log(err);
            done();
            
        });
       }); 

       it('GET/randomMeal5', (done) => {
        request.get(`random.php`).end((err,res) => {
        expect(res.body.meals).to.not.be.empty;
        expect(res.status).to.equal(200);
        expect(res.body.meals[0].strIngredient1).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient2).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient3).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient4).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient5).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient6).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient7).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient8).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient9).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient10).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient11).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient12).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient13).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient14).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient15).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient16).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient17).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient18).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient19).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient20).to.not.equal('Garlic');
       // console.log(res.body.meals[0]);
      //  console.log(res.status);
       // console.log(err);
            done();
            
        });
       }); 

       it('GET/randomMeal6', (done) => {
        request.get(`random.php`).end((err,res) => {
        expect(res.body.meals).to.not.be.empty;
        expect(res.status).to.equal(200);
        expect(res.body.meals[0].strIngredient1).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient2).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient3).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient4).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient5).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient6).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient7).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient8).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient9).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient10).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient11).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient12).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient13).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient14).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient15).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient16).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient17).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient18).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient19).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient20).to.not.equal('Garlic');
       // console.log(res.body.meals[0]);
      //  console.log(res.status);
       // console.log(err);
            done();
            
        });
       }); 

       it('GET/randomMeal7', (done) => {
        request.get(`random.php`).end((err,res) => {
        expect(res.body.meals).to.not.be.empty;
        expect(res.status).to.equal(200);
        expect(res.body.meals[0].strIngredient1).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient2).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient3).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient4).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient5).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient6).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient7).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient8).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient9).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient10).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient11).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient12).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient13).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient14).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient15).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient16).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient17).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient18).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient19).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient20).to.not.equal('Garlic');
       // console.log(res.body.meals[0]);
      //  console.log(res.status);
       // console.log(err);
            done();
            
        });
       }); 

       it('GET/randomMeal8', (done) => {
        request.get(`random.php`).end((err,res) => {
        expect(res.body.meals).to.not.be.empty;
        expect(res.status).to.equal(200);
        expect(res.body.meals[0].strIngredient1).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient2).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient3).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient4).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient5).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient6).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient7).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient8).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient9).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient10).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient11).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient12).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient13).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient14).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient15).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient16).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient17).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient18).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient19).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient20).to.not.equal('Garlic');
       // console.log(res.body.meals[0]);
      //  console.log(res.status);
       // console.log(err);
            done();
            
        });
       }); 

       it('GET/randomMeal9', (done) => {
        request.get(`random.php`).end((err,res) => {
        expect(res.body.meals).to.not.be.empty;
        expect(res.status).to.equal(200);
        expect(res.body.meals[0].strIngredient1).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient2).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient3).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient4).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient5).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient6).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient7).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient8).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient9).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient10).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient11).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient12).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient13).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient14).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient15).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient16).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient17).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient18).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient19).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient20).to.not.equal('Garlic');
       // console.log(res.body.meals[0]);
      //  console.log(res.status);
       // console.log(err);
            done();
            
        });
       }); 

       it('GET/randomMeal10', (done) => {
        request.get(`random.php`).end((err,res) => {
        expect(res.body.meals).to.not.be.empty;
        expect(res.status).to.equal(200);
        expect(res.body.meals[0].strIngredient1).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient2).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient3).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient4).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient5).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient6).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient7).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient8).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient9).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient10).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient11).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient12).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient13).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient14).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient15).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient16).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient17).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient18).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient19).to.not.equal('Garlic');
        expect(res.body.meals[0].strIngredient20).to.not.equal('Garlic');
       // console.log(res.body.meals[0]);
      //  console.log(res.status);
       // console.log(err);
            done();
            
        });
       }); 

      
});















